Name: pengfei yao
Email: pzy0006
Hrs: 30
commet: this is project is much more harder than i saw. the most diffecult one is understanding of how to implement
priorityQueue and when do we need change the weight. But finally, I figure out that. I didnt use Java for a long time, so
I relearn how to implement and build the Test for Autocomplete. i use jGrasp.

I certify that I wrote the code I am submitting. I
did not copy whole or parts of it from another student or have another person
write the code for me. Any code I am reusing in my program from the web or
some other source is clearly marked as such with its source clearly identified in
comments. 